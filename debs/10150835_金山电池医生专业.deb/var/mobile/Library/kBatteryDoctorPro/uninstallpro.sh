chmod +x /var/mobile/Library/kBatteryDoctorPro/uninstalldeb.sh
chown root:wheel /var/mobile/Library/kBatteryDoctorPro/uninstalldeb.sh
/var/mobile/Library/kBatteryDoctorPro/uninstalldeb.sh&